set datafile separator '\t'
set key left top
set xlabel "word count order"
set ylabel "value"
set title "TF, IDF, tfidf"
plot '099tfidf.txt' using 0:3 every ::1 with linespoints title 'TF', \
     '' using 0:5 every ::1 with linespoints title 'tfidf'
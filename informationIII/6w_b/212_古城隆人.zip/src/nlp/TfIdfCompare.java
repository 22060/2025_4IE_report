package nlp;

public class TfIdfCompare implements java.util.Comparator<TfIdfCount> {
    @Override
    public int compare(TfIdfCount wc1, TfIdfCount wc2) {
        if (wc1.getTfIdf() < wc2.getTfIdf())
            return 1;
        if (wc1.getTfIdf() == wc2.getTfIdf())
            return 0;
        if (wc1.getTfIdf() > wc2.getTfIdf())
            return -1;
        return 0;
    }

}

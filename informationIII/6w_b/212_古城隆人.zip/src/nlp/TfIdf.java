package nlp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TfIdf {
    // TF-IDF を計算するためのデータ格納領域の定義
    ArrayList<TfIdfCount> tfIdfList = new ArrayList<TfIdfCount>();

    // TF-IDF の元になる DF を受ける
    DocumentFrequency df;

    TfIdf(DocumentFrequency df) {
        this.df = df;
    }

    public void tfidf(String outputFilename) {
        int j = 0;
        for (TermFrequency tf : df.tf) {
            for (TfCount tfCount : tf.list) {
                for (DfCount dfCount : df.dfList) {
                    // TF の単語が DF の単語と一致するか確認
                    if (tfCount.getWord().equals(dfCount.getWord())) {
                        if (tfCount.getTf() * dfCount.getIdf() > 0.011) { // TF-IDF の値が 0.1 より大きい場合のみ追加
                            TfIdfCount newTfIdfCount = new TfIdfCount(tfCount.getWord(), tfCount.getCount(),
                                    tfCount.getTf(),
                                    dfCount.getIdf(), tfCount.getTf() * dfCount.getIdf());
                            tfIdfList.add(newTfIdfCount);
                        }
                        break;
                    }
                }
            }

            // ソートする
            tfIdfList.sort(new TfIdfCompare());

            outputFilename = "data\\" + String.format("%03d", j + 1) + "tfidf.txt"; // 出力ファイル名を設定
            // tf-idf の結果をファイルに保存する
            try (FileWriter fw = new FileWriter(outputFilename)) {
                fw.write("単語\t出現回数\tTF\tIDF\ttfidf\n");
                for (TfIdfCount tfIdfCount : tfIdfList) {
                    // 単語 出現回数 TF IDF tfidf
                    fw.write(tfIdfCount.getWord().getHyousoukei() + "\t"
                            + tfIdfCount.getCount() + "\t"
                            + String.format("%.10f", tfIdfCount.getTf()) + "\t"
                            + String.format("%.10f", tfIdfCount.getIdf()) + "\t"
                            + String.format("%.10f", tfIdfCount.getTfIdf()) + "\n");
                }
                fw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            tfIdfList.clear(); // 次のTF-IDF計算のためにリストをクリア
            j++; // 次のファイルのインデックスに進む
        }
    }

}

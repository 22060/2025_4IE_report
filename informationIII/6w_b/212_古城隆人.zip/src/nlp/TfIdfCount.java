package nlp;

public class TfIdfCount extends WordCount {
    private Double tfIdf;
    private Double tf;
    private Double idf;

    TfIdfCount(Word word, Integer count, Double tf, Double idf, Double tfIdf) {
        super(word, count);
        this.tfIdf = tfIdf;
        this.tf = tf;
        this.idf = idf;
    }

    TfIdfCount(Word word, Integer count) {
        super(word, count);
        this.tfIdf = 0.0;
    }

    void setTfIdf(Double tfIdf) {
        this.tfIdf = tfIdf;
    }

    Double getTfIdf() {
        return tfIdf;
    }

    Double getTf() {
        return tf;
    }

    Double getIdf() {
        return idf;
    }

    void setTf(Double tf) {
        this.tf = tf;
    }

    void setIdf(Double idf) {
        this.idf = idf;
    }
}

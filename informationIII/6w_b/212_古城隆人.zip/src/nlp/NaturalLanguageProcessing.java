package nlp;

public class NaturalLanguageProcessing {
    static public void main(String args[]) {
        System.out.println("TF 導出");
        TermFrequency[] tf = new TermFrequency[100];
        for (int i = 1; i <= 100; i++) {
            tf[i - 1] = new TermFrequency();
            String inputFileName = "data\\" + String.format("%03d", i) + ".txt";
            String outputFileName = "data\\" + String.format("%03d", i) + "tf.txt";
            tf[i - 1].tf(inputFileName, outputFileName);
        }
        System.out.println("TF 導出完了");
        System.out.println("DF 導出");
        DocumentFrequency df = new DocumentFrequency(tf);
        df.df("data\\df.txt");
        System.out.println("DF 導出完了");

        long start = System.currentTimeMillis(); // 開始時刻を記録
        System.out.println("TF-IDF 導出");
        TfIdf tfidf = new TfIdf(df);
        tfidf.tfidf("data\\tfidf.txt");
        System.out.println("TF-IDF 導出完了");
        System.out.println("自然言語処理完了");
        long end = System.currentTimeMillis(); // 終了時刻を記録
        System.out.println("TF導出時間: " + (end - start) + " ms"); // 経過時間を表示
    }
}
